﻿
namespace UnityUtility
{
	public enum UpdateType
	{
		Manual,
		Update,
		FixedUpdate,
		LateUpdate,
	}
}
